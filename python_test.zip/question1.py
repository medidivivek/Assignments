data = [10, 20, 30, 40, 50, 20, 30, 60, [70, 80], 90]
#subQestion 1
data.append([100, 110])
print(data)
#subQestion 2
data.extend([120, 130])
print(data)
#subQestion 3
data.insert(2, 25)
print(data)
#subQestion 4
data.remove(20)
print(data)
#subQestion 5
le = data.pop()
print("Pop ele:", le)
#subQestion 6
count = data.count(30)
print("Count of 30:", count)
#subQestion 7
index_40 = data.index(40)
print("Index of 40:", index_40)
#subQestion 8
data.reverse()
print(data)
#subQestion 9
# data.sort()   sorting not possible with nested list