t = (10, 20, 30, 40, 50, 20, 60)
#subquestion1
print(t.count(20)) 
#subquestion2
print(t.index(40)) 
#subquestion3
temp = list(t)
temp.append(70)
t = tuple(temp)
print(t)
#subquestion4
print(t[2:6])  
#subquestion5
t2 = (80, 90)
t = t + t2
print(t)
#subquestion6
print(t * 2)
#subquestion7
print(50 in t)
#subquestion8
a, b, c, d, e, f, g, *rest = t
print(a, b, c)
print(rest)
#subquestion9
# Tuple is immutable
#subquestion10
nested = (1, 2, (3, 4, 5))
print(nested[2][1]) 