s1 = {10, 20, 30, 40}
s2 = {30, 40, 50, 60}
#subquestion1
s1.add(60)
print(s1)
#subquestion2
s1.update([70, 80, 90])
print(s1)
#subquestion3
s1.remove(20)
print(s1)
#subquestion4
s1.discard(100)
#subquestion5
removed = s1.pop()
print("Removed:", removed)
#subquestion6
copy_set = s1.copy()
copy_set.add(999)

print("Original:", s1)
print("Copy:", copy_set)
#subquestion7
s1.clear()
print(len(s1))
#subquestion8
lst = [1, 2, 2, 3, 3, 4]
unique = set(lst)
print(unique)
#subquestion9
lst = list(unique)
lst.sort()
print(lst)