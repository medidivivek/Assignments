student = {
    "name": "John",
    "age": 21,
    "marks": {"math": 80, "science": 90}
}
#subquestion1
print(student.get("name")) 
#subquestion2
student["grade"] = "B"
#subquestion3
student.update({"age": 22})
#subquestion4
student.pop("age")
#subquestion5
student.popitem()
#subquestion6
print(student.keys())
#subquestion7
print(student.values())
#subquestion8
print(student.items())
#subquestion9
student.setdefault("city", "Hyderabad")
#subquestion10
student.update({"phone": "9553251655"})