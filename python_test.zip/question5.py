def calculate_ticket_price(seats, timing, is_weekend):
    # Base prices
    seat_prices = {
        "VIP": 500,
        "REGULAR": 300,
        "ECONOMY": 150
    }

    timing_multiplier = {
        "morning": 0.8,
        "afternoon": 1,
        "evening": 1.2,
        "night": 1.5
    }

    valid_seats = [seat for seat in seats if seat in seat_prices]

    if not valid_seats:
        return "No valid booking"

    base_total = sum(seat_prices[seat] for seat in valid_seats)

    multiplier = timing_multiplier.get(timing.lower(), 1)
    timing_adjustment = base_total * multiplier

    if is_weekend:
        timing_adjustment *= 1.10

    discount = 0
    if len(valid_seats) >= 5:
        discount = timing_adjustment * 0.15
        timing_adjustment -= discount

    booking_fee = 50 * len(valid_seats)
    total_after_fee = timing_adjustment + booking_fee

    tax = total_after_fee * 0.12

    final_amount = total_after_fee + tax

    return {
        "base_total": round(base_total),
        "timing_adjustment": round(timing_adjustment),
        "discount": round(discount),
        "tax": round(tax),
        "final_amount": round(final_amount)
    }


seats = ["VIP", "REGULAR", "ECONOMY", "VIP", "REGULAR"]
timing = "night"
is_weekend = False

result = calculate_ticket_price(seats, timing, is_weekend)
print(result)