function addToCart() {
    alert("Item added to cart!");
}

function validateForm() {

    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;
    let pin = document.getElementById("pin").value;
    let terms = document.getElementById("terms").checked;

    if (name === "") {
        alert("Name is required");
        return false;
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
        alert("Invalid email");
        return false;
    }

    if (!/^[0-9]{10}$/.test(phone)) {
        alert("Phone must be 10 digits");
        return false;
    }

    if (!/^[0-9]{6}$/.test(pin)) {
        alert("PIN must be 6 digits");
        return false;
    }

    if (!terms) {
        alert("Accept terms");
        return false;
    }

    alert("Order placed successfully!");
    return true;
}